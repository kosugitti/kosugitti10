##############################################
#
#    Rでらくらく心理統計 / 　小杉考司(著)　/　4章で使ったコード
#
##############################################

set.seed(10)
N <- 20
X <- runif(N,1,100)
Yhat <- X*0.8+10
Y <- Yhat + rnorm(N,0,10)
plot(X,Y)

summary(lm(Y~X))

data(iris)
summary(lm(Sepal.Length ~ Petal.Length + Petal.Width,data=iris))

iris$Sepal.Length2 <- iris$Sepal.Length * 10
summary(lm(Sepal.Length2 ~ Petal.Length + Petal.Width,data=iris))

iris.z <- data.frame(scale(iris[1:4])) # 標準化する関数scaleを使う
summary(lm(Sepal.Length ~ Petal.Length + Petal.Width,data=iris.z))

