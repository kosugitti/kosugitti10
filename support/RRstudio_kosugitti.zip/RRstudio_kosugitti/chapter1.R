##############################################
#
#    Rでらくらく心理統計 / 　小杉考司(著)　/　1章で使ったコード
#
##############################################



# まずは足し算
2+3

# ここから違うことをする -------------------------------------------------------------

2+3
3-4
4*5
5/6

sqrt(16)

?sqrt

obj <- 2
obj
xobj2 <- 2
obj3 <- 3
obj2 + obj3
obj <- 1:10
obj
obj * 2
obj <- matrix(c(1:10),nrow=5)
obj

obj * 2

obj[1,]
obj[,2]


obj<-list(name=c("kosugi","tanaka","suzuki"),
          gender=c("male","female","male"),
          height=c(170,160),
          weight=c(70.6,80.9,90.6,40.3))
obj

obj$name
str(obj)


obj<-data.frame(
  list(name=c("kosugi","tanaka","suzuki"),
       gender=c(1,2,1),
       hight=c(170,160,170),
       weight=c(70.6,80.9,90.6)
  )
)
str(obj)
obj$gender<-factor(obj$gender,labels=c("male","female"))
obj
