##############################################
#
#    Rでらくらく心理統計 / 　小杉考司(著)　/　8章で使ったコード
#
##############################################

set.seed(8)
mu <- 10
sig <- 1
N <- 20
X1 <- mu + rnorm(N,0,sig)
X2 <- mu + rnorm(N,0,sig)
X3 <- mu + rnorm(N,0,sig)

mean(X1)
mean(X2)
mean(X3)

dat <- data.frame(
    group=factor(c(rep(1,N),rep(2,N),rep(3,N))),val=c(X1,X2,X3)
  )

summary(dat)

summary(aov(val~group,dat))

mu <- 10
sig <- 5
N <- 20
X1 <- mu + rnorm(N,0,sig)
X2 <- mu + 5 + rnorm(N,0,sig)
X3 <- mu - 5 + rnorm(N,0,sig)
dat <- data.frame(
  group=factor(c(rep(1,N),rep(2,N),rep(3,N))),
  val=c(X1,X2,X3))
summary(aov(val~group,dat))


TukeyHSD(aov(val~group,dat))


mu <- 50         # 平均点
sig <- 5         # 学級内での点数の散らばり
N <- 20          # 学級の人数
X1 <- rnorm(N,mu,sig) 　　　　　#1学期の成績
X2 <- X1 + 10 + rnorm(N,0,3)    #2学期＝1学期＋効果＋誤差
X3 <- X2 + 10 + rnorm(N,0,3)    #3学期＝2学期＋効果＋誤差
dat <- data.frame(score=c(X1,X2,X3))
dat$ID <- factor(rep(1:N,3))
dat$period <- factor(rep(1:3,each=N),labels=c("T1","T2","T3"))

summary(aov(score~period+Error(ID/period),data=dat))

pairwise.t.test(dat$score , dat$period, p.adjust.method="bonferroni", paired=TRUE )
pairwise.t.test(dat$score , dat$period, p.adjust.method="holm", paired=TRUE )
