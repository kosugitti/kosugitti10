##############################################
#
#    Rでらくらく心理統計 / 　小杉考司(著)　/　3章で使ったコード
#
##############################################

data("HairEyeColor")
HairEyeColor
prop.table(HairEyeColor,margin = 3)

data(Titanic)
Titanic

Titanic[,1,2,]

Titanic[,"Male","Adult",]

prop.table(Titanic[,"Male","Adult",],margin=1)

prop.table(Titanic[,"Male","Adult",],margin=2)

