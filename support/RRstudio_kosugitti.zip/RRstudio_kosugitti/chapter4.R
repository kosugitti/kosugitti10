##############################################
#
#    Rでらくらく心理統計 / 　小杉考司(著)　/　4章で使ったコード
#
##############################################

set.seed(12345)
N <- 1000
Y <- as.integer(rnorm(N,50,10))

Y

hist(Y)

# 平均
mean(Y)
# 個々のデータの平均からのズレ
# Y - mean(Y)
# 個々のデータの平均からのずれの二乗
# (Y - mean(Y))^2
# 個々のデータの平均からのずれの二乗の平均＝分散
# mean((Y - mean(Y))^2)
# 分散をオブジェクトvarYに代入
varY <- mean((Y - mean(Y))^2)
varY
# 分散の平方根 = 標準偏差
sqrt(varY)

# データセットYの1番目から10番目までの要素を取り出し，sample1に代入します
sample1 <- Y[1:10]
# sample1の中身
sample1
# sample1の平均
mean(sample1)
# sample1の標準偏差
sqrt(mean((sample1-mean(sample1))^2))


# sample関数は二つの引数をとる。sample(A,B)でオブジェクトAからB個のデータをランダムに抜き出す
# ここではデータセットYから10個抜き出して，sample2に代入しています。
sample2 <- sample(Y,10)
# sample2の中身
sample2
# sample2の平均
mean(sample2)
# sample2の標準偏差
sqrt(mean((sample2-mean(sample2))^2))

sample3 <- sample(Y,10)
mean(sample3)
sqrt(mean((sample3-mean(sample3))^2))

sample4 <- sample(Y,10)
mean(sample4)
sqrt(mean((sample4-mean(sample4))^2))

sample5 <- sample(Y,10)
mean(sample5)
sqrt(mean((sample5-mean(sample5))^2))

SAM <- list()
M <- c()
SD <- c()
for(tr in 1:20){
  SAM[[tr]] <- sample(Y,10)
  M[tr] <- mean(SAM[[tr]])
  SD[tr] <- sqrt(mean((SAM[[tr]]-mean(SAM[[tr]]))^2))
}

library(xtable)
xtable(rbind(M,SD))


mean(M)
mean(SD)
var(M)


SAM <- list()
M <- c()
SD <- c()
M2 <- c()
for(tr in 1:50){
  SAM[[tr]] <- sample(Y,10)
  M[tr] <- mean(SAM[[tr]])
  SD[tr] <- sd(SAM[[tr]])
  M2[tr] <- mean(M[1:tr])
}

M2df <- data.frame(M2)
M2df$index <- 1:nrow(M2df)
library(ggplot2)
old = theme_set(theme_gray(base_family = "HiraKakuProN-W3"))

g <- ggplot(M2df,aes(x=index,y=M2))+geom_line()+ylim(45,55)
g <- g+xlab("サンプリング回数") + ylab("平均値の平均値")
g
