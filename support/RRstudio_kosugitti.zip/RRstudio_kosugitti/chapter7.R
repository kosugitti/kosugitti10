##############################################
#
#    Rでらくらく心理統計 / 　小杉考司(著)　/　7章で使ったコード
#
##############################################

# 乱数の開始地点を決めます。カッコの中はどんな数字でも構いません。
set.seed(7)
# データのサイズをNとして決めます。今回は10にします。
N <- 10
# 二つのグループの平均をそれぞれmuA,muBというオブジェクトに入れます
muA <- 10
muB <- 20
# 二つのグループで共通する標準偏差(分散の正の平方根)の大きさを決めます。
sigma <- 10
# 二つのグループの数字を正規乱数からN個作ります。
X1 <- rnorm(N,muA,sigma)
X2 <- rnorm(N,muB,sigma)
# 二つのグループの平均値の差をt検定します
t.test(X1,X2)
t.test(X1,X2,var.equal = TRUE)

# 平均値の差を小さくした
set.seed(7)
N <- 10
muA <- 10
muB <- 12
sigma <- 10
X1 <- rnorm(N,muA,sigma)
X2 <- rnorm(N,muB,sigma)
t.test(X1,X2)

# 分散(SD)を小さくした
set.seed(7)
N <- 10
muA <- 10
muB <- 12
sigma <- 1
X1 <- rnorm(N,muA,sigma)
X2 <- rnorm(N,muB,sigma)
t.test(X1,X2)

# サンプルサイズを増やした
set.seed(7)
N <- 500
muA <- 10
muB <- 12
sigma <- 10
X1 <- rnorm(N,muA,sigma)
X2 <- rnorm(N,muB,sigma)
t.test(X1,X2)

# 対応のあるt検定
# 乱数の開始地点を決めます。カッコの中はどんな数字でも構いません。
set.seed(7)
# データのサイズをNとして決めます。今回は10にします。
N <- 10
# X1のデータは平均10，標準偏差5の正規分布に従うものとして作ります。
mu_pre <- 10
sigma <- 5
X1 <- rnorm(N,mu_pre,sigma)
# 効果は平均3，標準偏差7の正規分布に従って現れるとします。個人ごとに効果は違いますから，
# 人数分(N個)の正規乱数を発生させます。
diff <- rnorm(N,3,7)
# X2 のデータはX1のデータにそれぞれの効果が加わります
X2 <- X1 + diff

t.test(X1,X2,paired = TRUE)
t.test(X1,X2,paired = TRUE,alternative = "less")


df <- data.frame(X1=X1,X2=X2,ID=1:N)
library(ggplot2)
df2 <- tidyr::gather(df,key,val,-ID)
df2$key <- factor(df2$key)
df2$ID <- factor(df2$ID)
g <- ggplot(df2,aes(x=key,y=val,group=ID,color=ID))
g <- g + geom_line() + geom_point() 
#g <- g + geom_hline(yintercept = mean(X1),lty=2) + geom_hline(yintercept = mean(X2),lty=2)
g <- g + xlab("") + ylab("")
g
summary(aov(dat$val~dat$group))

