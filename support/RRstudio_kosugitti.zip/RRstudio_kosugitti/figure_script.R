##############################################
#
#    Rでらくらく心理統計 / 　小杉考司(著)　/　各章に含まれている図表を作ったコード
#
##############################################


library(ggplot2)
old = theme_set(theme_gray(base_family="HiraKakuProN-W3"))


# Chapter3 ----------------------------------------------------------------

data("HairEyeColor")
## 相関係数
library(MASS)
mu <- c(0,0)
sig <- matrix(nrow=2,ncol=2)
N <- 2000
dat <- NULL
for(rho in seq(-1,1,0.25)){
  sig[1,1] <- 1
  sig[1,2] <- rho
  sig[2,1] <- rho
  sig[2,2] <- 1
  tmp <- data.frame(mvrnorm(N,mu,sig),rho)
  dat <- rbind(dat,tmp)
}

dat$rho <- factor(dat$rho)
library(ggplot2)
g <- ggplot(dat,aes(x=X1,y=X2))+geom_point()+facet_wrap(~rho)
g

### 逆U字
x <- rep(seq(-1.5,4.5,0.1),200)
y <- sin(x)
z <- rnorm(length(x),0,0.6)
dat <- data.frame(scale(cbind(x,y+z)))
v <- 1:length(x)
v2 <- sample(v,250)
dat <- dat[v2,]
names(dat) <- c("V1","V2")
ggplot(dat,aes(x=V1,y=V2))+geom_point()
cor(dat)

### 打ち切りデータ
N <- 1000
mu <- c(0,0)
Sig <- matrix(c(1,0.7,0.7,1),nrow=2)
dat <- as.data.frame(mvrnorm(N,mu,Sig,empirical = T))
dat$V1 <- 10 * dat$V1 + 50
dat$V2 <- 10 * dat$V2 + 50
plot(dat)
dat$judge <- ifelse(dat$V1<60,2,1)
dat$judge <- factor(dat$judge,labels=c("pass","fail"))
old = theme_set(theme_gray(base_family="HiraKakuProN-W3"))
g <- ggplot(dat,aes(x=V1,y=V2,color=judge,shape=judge))
g <- g + geom_point()+xlab("入試の得点")+ylab("入学後の成績")+geom_vline(xintercept=60)
g
cor(dat[,1],dat[,2])
subdat <- subset(dat,dat$judge=="pass")
cor(subdat[,1],subdat[,2])


### 複数の異なる群
N <- 100
X1 <- rnorm(N,10,15)
X2 <- rnorm(N,40,15)
X3 <- rnorm(N,70,15)
Y1 <- X1 * -0.3 + rnorm(N,0,10) + 10
Y2 <- X2 * -0.3 + rnorm(N,0,10) + 50
Y3 <- X3 * -0.3 + rnorm(N,0,10) + 80
dat <- data.frame(rbind(cbind(X1,Y1),cbind(X2,Y2),cbind(X3,Y3)))
cor(dat[,1:2])
dat$group <- factor(rep(1:3,each=N),labels=c("Group A","Group B","Group C"))
g <- ggplot(dat,aes(x=X1,y=Y1))+geom_point()
g

g <- ggplot(dat,aes(x=X1,y=Y1,shape=group,color=group))+geom_point()
g

cor(X1,Y1)
cor(X2,Y2)
cor(X3,Y3)


# Chapter4 ----------------------------------------------------------------

set.seed(12345)
N <- 1000
Y <- as.integer(rnorm(N,50,10))
Y

SAM <- list()
M <- c()
SD <- c()
M2 <- c()
for(tr in 1:30){
  SAM[[tr]] <- sample(Y,10)
  M[tr] <- mean(SAM[[tr]])
  SD[tr] <- sd(SAM[[tr]])
  M2[tr] <- mean(M[1:tr])
}

M2df <- data.frame(M2)
M2df$index <- 1:nrow(M2df)
library(ggplot2)
g <- ggplot(M2df,aes(x=index,y=M2))+geom_line()+ylim(45,55)
g <- g+xlab("サンプリング回数") + ylab("平均値の平均値")
g


Maxtr <- 50
 
dat <- data.frame(matrix(nrow=Maxtr,ncol=4))
dat$index <- 1:Maxtr

for(tr in 1:Maxtr){
  dat$X1[tr] <- mean(sample(Y,10))
  dat$X2[tr] <- mean(sample(Y,50))
  dat$X3[tr] <- mean(sample(Y,100))
  dat$X4[tr] <- mean(sample(Y,200))
}

dat$X1ave[1] <- dat$X1[1]
dat$X2ave[1] <- dat$X2[1]
dat$X3ave[1] <- dat$X3[1]
dat$X4ave[1] <- dat$X4[1]

for(tr in 2:Maxtr){
  dat$X1ave[tr] <- mean(dat$X1[1:tr])
  dat$X2ave[tr] <- mean(dat$X2[1:tr])
  dat$X3ave[tr] <- mean(dat$X3[1:tr])
  dat$X4ave[tr] <- mean(dat$X4[1:tr])
}

dat2 <- tidyr::gather(dat[5:9],key,value,-index)
dat2$key <- factor(dat2$key,label=c("N=10","N=50","N=100","N=200"))

library(ggplot2)
g <- ggplot(dat2,aes(x=index,y=value))+geom_line()+ylim(43,57)
g <- g+xlab("サンプリング回数") + ylab("平均値の平均値")+facet_wrap(~key)
g



# 不偏分散
Maxtr <- 500

dat <- data.frame(matrix(nrow=Maxtr,ncol=2))
dat$index <- 1:Maxtr

for(tr in 1:Maxtr){
  dat$X1[tr] <- var(sample(Y,10))
  dat$X2[tr] <- (var(sample(Y,10))*9)/10
}


dat$X1ave[1] <- dat$X1[1]
dat$X2ave[1] <- dat$X2[1]

for(tr in 2:Maxtr){
  dat$X1ave[tr] <- mean(dat$X1[1:tr])
  dat$X2ave[tr] <- mean(dat$X2[1:tr])
}

dat2 <- tidyr::gather(dat[3:5],key,value,-index)
dat2$key <- factor(dat2$key,label=c("N-1で割ったもの","Nで割ったもの"))

library(ggplot2)
g <- ggplot(dat2,aes(x=index,y=value))+geom_line()+ylim(0,200)+geom_hline(yintercept=100,color="red")
g <- g+xlab("サンプリング回数") + ylab("分散の平均値")+facet_wrap(~key)
g



# Chapter6 ----------------------------------------------------------------


library(ggplot2)
x <- -0.0:10
qplot(x, geom = "blank") + stat_function(fun = function(x)x^2)

#組み込みの確率分布等使う時は、引数をargsにリストの形で渡す
my.df <-data.frame(x = c(0,10))
g <- ggplot(my.df,aes(x=x)) + 
    stat_function(fun = dchisq,args=list(df=1),aes(colour="自由度 1")) + 
    stat_function(fun = dchisq,args=list(df=2),aes(colour="自由度 2")) + 
    stat_function(fun = dchisq,args=list(df=3),aes(colour="自由度 3")) + 
    stat_function(fun = dchisq,args=list(df=4),aes(colour="自由度 4")) + 
    stat_function(fun = dchisq,args=list(df=5),aes(colour="自由度 5")) + 
    scale_colour_manual("自由度", values = c("black","red", "blue", "green", "orange")) + 
    xlab("") + ylab("") + 
    theme_bw(base_family="HiraKakuProN-W3")
g


# Chapter7 ----------------------------------------------------------------
# 分散分析説明用の図
set.seed(2356)
muA <- 50
muB <- 60
muC <- 70
sig <- 17

N <- 30
X1 <- rnorm(N,muA,sig)
X2 <- rnorm(N,muB,sig)
X3 <- rnorm(N,muC,sig)
df <- data.frame(cbind(X1,X2,X3))
mean(X1)
mean(X2)
mean(X3)
sd(X1)
sd(X2)
sd(X3)

summary(df)
df2 <- tidyr::gather(df)
df2$key <- as.factor(df2$key)
g <- ggplot(df2,aes(x=key,y=value))+ylim(0,100)
g <- g + geom_bar(stat="summary",fun.y="mean")
g <- g + geom_jitter(aes(color=key),size=4)
g <- g + xlab("Class")+ylab("Score")+ theme(legend.position="none")
g


muA <- 50
muB <- 60
muC <- 70
sig <- 3

N <- 30
X1 <- rnorm(N,muA,sig)
X2 <- rnorm(N,muB,sig)
X3 <- rnorm(N,muC,sig)
mean(X1)
mean(X2)
mean(X3)
sd(X1)
sd(X2)
sd(X3)
df <- data.frame(cbind(X1,X2,X3))
names(df) <- c("class A", "class B","class C")
df2 <- tidyr::gather(df)
df2$key <- as.factor(df2$key)
g <- ggplot(df2,aes(x=key,y=value))+ylim(0,100)
g <- g + geom_bar(stat="summary",fun.y="mean")
g <- g + geom_jitter(aes(color=key),size=4)
g <- g + xlab("Class")+ylab("Score")+ theme(legend.position="none")
g

# Chapter10 ----------------------------------------------------------------

set.seed(20170623)
library(ggplot2)
old = theme_set(theme_gray(base_family="HiraKakuProN-W3"))
library(MASS)

N <- 100
X <- data.frame(mvrnorm(N,c(0,0),matrix(c(1,0.7,0.7,1),nrow=2)))
names(X) <- c("X","Y")
g <- ggplot(X,aes(x=X,y=Y))+geom_point()
g <- g + geom_smooth(method="lm",se=FALSE)
g

N <- 100
X <- data.frame(mvrnorm(N,c(0,0),matrix(c(1,0.7,0.7,1),nrow=2)))
names(X) <- c("X","Y")
g <- ggplot(X,aes(x=X,y=Y))+geom_point()+ geom_smooth(method="lm",se=FALSE)
g <- g+geom_abline(intercept = 2, slope = -1,lty=3)
g <- g+geom_abline(intercept = 1, slope = 1,lty=4)
g <- g+geom_abline(intercept = -1, slope = 0.3,lty=5)
g

result <- lm(Y~X,data=X)
v1 <- 5
v2 <- 8
v3 <- 9
v4 <- 10
v5 <- 13
g <- ggplot(X,aes(x=X,y=Y))+geom_point()+ geom_smooth(method="lm",se=FALSE)
g <- g + geom_segment(x=X[v1,1], y=X[v1,2], xend=X[v1,1], yend=result$fitted.values[v1],lty=3)
g <- g + geom_segment(x=X[v2,1], y=X[v2,2], xend=X[v2,1], yend=result$fitted.values[v2],lty=3)
g <- g + geom_segment(x=X[v3,1], y=X[v3,2], xend=X[v3,1], yend=result$fitted.values[v3],lty=3)
g <- g + geom_segment(x=X[v4,1], y=X[v4,2], xend=X[v4,1], yend=result$fitted.values[v4],lty=3)
g <- g + geom_segment(x=X[v5,1], y=X[v5,2], xend=X[v5,1], yend=result$fitted.values[v5],lty=3)
g

set.seed(10)
library(ggplot2)
old = theme_set(theme_gray(base_family="HiraKakuProN-W3"))
library(MASS)

N <- 100
X <- data.frame(mvrnorm(N,c(0,0),matrix(c(1,0.7,0.7,1),nrow=2)))
names(X) <- c("X","Y")
summary(lm(Y~X,data=X))

X$group <- factor(ifelse(X$X<mean(X$X),0,1),labels=c("ctrl","exp"))
X$group2 <- ifelse(X$X<mean(X$X),-1,1)

g <- ggplot(NULL)
g <- g + geom_point(data=X,aes(x=X,y=Y))
g <- g + geom_smooth(data=X,aes(x=X,y=Y),method="lm",se=FALSE)
g <- g + geom_point(data=X,aes(x=group2,y=Y),shape=2,size=3)
g <- g + geom_hline(yintercept=-0.1,color="red",lty=2)
g


set.seed(20170623)
library(ggplot2)
old = theme_set(theme_gray(base_family="HiraKakuProN-W3"))
library(MASS)

N <- 100
X <- data.frame(mvrnorm(N,c(0,0),matrix(c(1,0.7,0.7,1),nrow=2)))
names(X) <- c("X","Y")
g <- ggplot(X,aes(x=X,y=Y))+geom_point()
g <- g + geom_smooth(method="lm",se=FALSE)
g

summary(lm(Y~X,data=X))

X$group <- factor(ifelse(X$X<mean(X$X),0,1),labels=c("ctrl","exp"))

g <- ggplot(X,aes(x=group,y=Y))+ geom_boxplot()
g <- g + geom_violin(alpha=0.3)
g

g <- ggplot(X,aes(x=group,y=Y))+geom_violin()
g <- g+stat_summary(geom="pointrange",fun.y = mean, fun.ymin = function(x) mean(x)-sd(x), 
                    fun.ymax = function(x) mean(x)+sd(x), size=1,alpha=.5)
g
t.test(Y~group,data=X)

# 二要因
N <- 100
X <- data.frame(mvrnorm(N,c(0,0,0),matrix(c(1,0.7,0.3,
                                            0.7,1,0,
                                            0.3,0,1),nrow=3)))
names(X) <- c("Y","X1","X2")
library(scatterplot3d)
par(family="HiraKakuProN-W3")
s3d <- scatterplot3d(X$X1,X$X2,X$Y, pch=16, highlight.3d=T,angle=55,
                     main="二つの独立変数と一つの従属変数からなる散布図")
s3d

s3d <- scatterplot3d(X$X1,X$X2,X$Y, pch=16, highlight.3d=T,angle=55,
                     main="二つの独立変数による重回帰平面")
fit <- lm(Y ~ X1+X2,data=X) 
summary(fit)
s3d$plane3d(fit)

X$X1.d <- factor(ifelse(X$X1<mean(X$X1),0,1),labels=c("A1","A2"))
X$X2.d <- factor(ifelse(X$X2<mean(X$X2),0,1),labels=c("B1","B2"))

s3d <- scatterplot3d(X$X1.d,X$X2.d,X$Y, pch=16, highlight.3d=T,angle=55,
                     main="二要因の実験計画モデルのデータ",
                     xlim=c(0,3),ylim=c(0,3))
s3d
s3d$plane3d(Intercept = 0,x.coef = 0,y.coef = 0,draw_polygon = T)

