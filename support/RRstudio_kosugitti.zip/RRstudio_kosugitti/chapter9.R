##############################################
#
#    Rでらくらく心理統計 / 　小杉考司(著)　/　9章で使ったコード
#
##############################################

set.seed(9)
mu <- 20        # 全体平均
N <- 10         # サンプルサイズ
effectA <- 5    # 要因Aの効果
effectB <- 0    # 要因Bの効果
effectAB <- 10  # 交互作用の効果
# 以下，理想的なデータの平均値
idealA1B1 <- mu + effectA + effectB + effectAB
idealA1B2 <- mu + effectA - effectB - effectAB
idealA2B1 <- mu - effectA + effectB - effectAB
idealA2B2 <- mu - effectA - effectB + effectAB

# 実際のデータはこれに誤差がついて得られる
sig <-3  # 誤差の大きさ
A1B1 <- idealA1B1 + rnorm(N,0,sig)
A1B2 <- idealA1B2 + rnorm(N,0,sig)
A2B1 <- idealA2B1 + rnorm(N,0,sig)
A2B2 <- idealA2B2 + rnorm(N,0,sig)
dat <- data.frame(value=c(A1B1,A1B2,A2B1,A2B2))
dat$factorA <- factor(rep(1:2,each=N*2),
                      labels=c("water","no-water"))
dat$factorB <- factor(rep(rep(1:2,each=N),2),
                      labels=c("sun","no-sun"))

summary(aov(value~factorA*factorB,data=dat))

# 同じデータを内要因だと考えて分析する
dat$ID <- factor(rep(1:N,4)) #個体差を識別する変数を用意する
result <- aov(value~(factorA*factorB)+Error(ID/(factorA*factorB)),data=dat)
summary(result)


# データを作る
muA <- 50        # A組平均点
muB <- 30        # B組平均点
sig <- 5         # 学級内での点数の散らばり
N <- 20          # 学級の人数

## A組のデータ
A1 <- rnorm(N,muA,sig) 　　　　　#1学期の成績
A2 <- A1 + 10 + rnorm(N,0,3)    #2学期＝1学期＋効果＋誤差
A3 <- A2 + 10 + rnorm(N,0,3)    #3学期＝2学期＋効果＋誤差
datA <- data.frame(score=c(A1,A2,A3))
datA$ID <- factor(rep(1:N,3))
datA$period <- factor(rep(1:3,each=N),
                      labels=c("T1","T2","T3"))

## B組のデータ
B1 <- rnorm(N,muB,sig) 　　　　#1学期の成績
B2 <- B1 + 5 + rnorm(N,0,3)    #2学期＝1学期＋効果＋誤差
B3 <- B2 + 5 + rnorm(N,0,3)    #3学期＝2学期＋効果＋誤差
datB <- data.frame(score=c(B1,B2,B3))
datB$ID <- factor(rep(21:(20+N),3))
datB$period <- factor(rep(1:3,each=N),
                      labels=c("T1","T2","T3"))

dat <- rbind(datA,datB)  #結合して一つのデータに

dat$class <- factor(c(rep(1,(N*3)),rep(2,(N*3))),labels=c("classA","classB"))
summary(aov(score~period*class+Error(ID/period + ID/period:class),data=dat))
